import importlib as ipl
import subprocess as sp
import time as tm
import sys
def check_lib(needPackages):
    print("运行这个程序需要一些库，我将会检查这些库是否已安装")
    missPackages=[]
    for pck in needPackages:
        try:
            ipl.import_module(pck)
            print(f"\033[32m✓\033[0m [{pck}]库已安装")
        except ImportError:
            missPackages.append(pck)
            print(f"\033[31m✗\033[0m [{pck}]库未安装")
        tm.sleep(0.2)
    if missPackages:
        print("发现未安装的库，正在尝试自动安装")
        missPackages2=[]
        for pck in missPackages:
            try:
                sp.check_call([sys.executable,"-m","pip","install",pck])
                print(f"\033[32m✓\033[0m [{pck}]库安装成功")
            except sp.CalledProcessError:
                missPackages2.append(pck)
                print(f"\033[31m✗\033[0m [{pck}]库安装失败")
            tm.sleep(0.2)
        if missPackages2:
            print("\033[31m✗\033[0m 部分库安装失败，请尝试在终端手动安装缺少的包")
            print("手动安装命令：")
            for pck in missPackages2:
                print(f"pip install {pck}")
                tm.sleep(0.2)
            print("程序已退出，请自行安装后重新运行")
            return
    print("\033[32m✓\033[0m 所有库都已安装完毕")